package com.corhuila.shoppingcar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoppingCarApplicationTests {

	@Test
	void contextLoads() {
	}

}
